#include "client.h"

ClientWidget::ClientWidget(MainWindow *parent)
{
    mainwindow=parent;

    Inresult=-1;
    //分配空间指定父对象
    tcpSocket = new QTcpSocket(this);

    connect(tcpSocket, QTcpSocket::connected,
            [=](){
        cout<<"连接成功"<<endl;
    });
    connect(tcpSocket,SIGNAL(readyRead()),this,SLOT(readMessage()));
    connect(tcpSocket, &QTcpSocket::disconnected,
            [=](){
    });

}

ClientWidget::~ClientWidget()
{
}

void ClientWidget::readMessage()
{
    QString str;
    QByteArray array;
    QString s1,s2,s3,s4,s5,s6,s7;
    int kind,level,accusationtimes,sectionnum;
    while(1)
    {
    array = tcpSocket->readLine();
    str=QString(array);
    if(str=="1\n")
    {
        array = tcpSocket->readLine();
        QString result;
        result=QString(array);
        result=result.left(result.length() - 1);
        mainwindow->changeuserkind(result.toInt());   //确定当前用户类型


        array = tcpSocket->readLine();
        QString result2;
        result2=QString(array);
        result2=result2.left(result2.length() - 1);
        Inresult=result2.toInt();   //判断是否符合标准

        if(Inresult==0)
        {
        QString s1,s2,s3,s4,s5,s6,s7;
        array = tcpSocket->readLine();
        s1=QString(array);
        s1=s1.left(s1.length() - 1);   //ID

        array = tcpSocket->readLine();
        s2=QString(array);
        s2=s2.left(s2.length() - 1);  //用户名

        array = tcpSocket->readLine();
        s3=QString(array);
        s3=s3.left(s3.length() - 1);  //密码

        array = tcpSocket->readLine();
        s4=QString(array);
        s4=s4.left(s4.length() - 1); //上次登录时间


        if(result=="0")
        {
            Administrator a(s1.toStdString(),s2.toStdString(),s3.toStdString(),s4.toStdString());
            mainwindow->pushAdministratorVector(a);
        }
        else if(result=="1")
        {
            Ordinaryuser o(s1.toStdString(),s2.toStdString(),s3.toStdString(),s4.toStdString());

            array = tcpSocket->readLine();
            s5=QString(array);
            s5=s5.left(s5.length() - 1); //等级
            level=s5.toInt();
            o.changeLevel(level);


            array = tcpSocket->readLine();
            s6=QString(array);
            s6=s6.left(s6.length() - 1); //被举报次数
            accusationtimes=s6.toInt();
            o.addAccusationtimes(accusationtimes);

            mainwindow->pushOrdinaryuserVector(o);

        }
        else if(result=="2")
        {
            Moderator o(s1.toStdString(),s2.toStdString(),s3.toStdString(),s4.toStdString());

            array = tcpSocket->readLine();
            s5=QString(array);
            s5=s5.left(s5.length() - 1); //等级
            level=s5.toInt();
            o.changeLevel(level);


            array = tcpSocket->readLine();
            s6=QString(array);
            s6=s6.left(s6.length() - 1); //被举报次数
            accusationtimes=s6.toInt();
            o.addAccusationtimes(accusationtimes);

            array = tcpSocket->readLine();
            s7=QString(array);
            s7=s7.left(s7.length() - 1); //板块
            sectionnum=s7.toInt();
            o.changeSection(sectionnum);

            mainwindow->pushModeratorVector(o);
        }
        else if(result=="3")
        {
            Anonymoususer a(s1.toStdString(),s2.toStdString(),s3.toStdString(),s4.toStdString());
            mainwindow->pushanonymoususerVector(a);
        }
        }


        mainwindow->changeUserOnline(Inresult);


    }
    else if(str=="2\n")
    {
        QString ID,userName,time,title,content,sectionnum;
        QString result,str;
        array = tcpSocket->readLine();
        ID=QString(array);
        ID=ID.left(ID.length()-1);
        int id = ID.toInt();

        array = tcpSocket->readLine();
        userName=QString(array);
        userName=userName.left(userName.length()-1);

        array = tcpSocket->readLine();
        time=QString(array);
        time=time.left(time.length()-1);

        array = tcpSocket->readLine();
        title=QString(array);
        title=title.left(title.length()-1);

        array = tcpSocket->readLine();
        sectionnum=QString(array);
        sectionnum=sectionnum.left(sectionnum.length() - 1);
        int section = sectionnum.toInt();

        content="";
        while(1)
        {
            array = tcpSocket->readLine();
            str=QString(array);
            if(str=="end\n")
                break;
            else
                content+=str;
        }
        content=content.left(content.length()-1);

        string s1,s2,s3,s4;
        s1=string((const char *)userName.toLocal8Bit());
        s2=string((const char *)title.toLocal8Bit());
        s3=string((const char *)time.toLocal8Bit());
        s4=string((const char *)content.toLocal8Bit());
        cout<<"userName:"<<s1<<endl;
        cout<<"title:"<<s2<<endl;
        cout<<"time:"<<s3<<endl;
        cout<<"content:"<<s4<<endl;
        cout<<"section:"<<section<<endl;
        Post p(s1,s2,s4,s3,id);
        p.changeSectionnum(section);
        mainwindow->addPosts(p);

        //mainwindow->posts.push_back(p);
    }
    else if(str=="3\n")
    {
        QString ID,userName,time,content,postid;
        QString result,str;
        array = tcpSocket->readLine();
        ID=QString(array);
        ID=ID.left(ID.length()-1);
        int id = ID.toInt();

        array = tcpSocket->readLine();
        userName=QString(array);
        userName=userName.left(userName.length()-1);

        array = tcpSocket->readLine();
        time=QString(array);
        time=time.left(time.length()-1);


        array = tcpSocket->readLine();
        postid=QString(array);
        postid=postid.left(postid.length() - 1);
        int post = postid.toInt();

        content="";
        while(1)
        {
            array = tcpSocket->readLine();
            str=QString(array);
            if(str=="end\n")
                break;
            else
                content+=str;
        }
        content=content.left(content.length()-1);

        string s1,s2,s3,s4;
        s1=string((const char *)userName.toLocal8Bit());
        s3=string((const char *)time.toLocal8Bit());
        s4=string((const char *)content.toLocal8Bit());
        cout<<"userName:"<<s1<<endl;
        cout<<"time:"<<s3<<endl;
        cout<<"content:"<<s4<<endl;
        cout<<"postid:"<<post<<endl;
        Comment c(s1,s4,s3,id);
        c.changepostid(post);

        mainwindow->addComments(c);
    }
    else if(str=="4\n")
    {
        QString m;
        int result;
        array = tcpSocket->readLine();
        m=QString(array);
        result=m.toInt();
        if(result==0)
        {
            QLabel*text=new QLabel("注册成功");  //弹出提示框注册成功
            text->setFixedSize(300,100);
            text->setVisible(true);
           // mainwindow->startForum();
        }
        else if(result==1)
        {
            QLabel*text=new QLabel("用户已存在");  //弹出提示框注册失败
            text->setFixedSize(300,100);
            text->setVisible(true);
        }
    }
    else if(str=="5\n")
    {
        QString result;
        array = tcpSocket->readLine();
        result=QString(array);
        if(result=="0\n")
        {
            QLabel*text=new QLabel("更改成功");  //弹出提示框注册成功
            text->setFixedSize(300,100);
            text->setVisible(true);
        }
        else if(result=="1\n")
        {
            QLabel*text=new QLabel("更改失败");  //弹出提示框注册成功
            text->setFixedSize(300,100);
            text->setVisible(true);
        }
    }
    else if(str=="6\n")
    {
        int id;
        array = tcpSocket->readLine();
        s1=QString(array);
        s1=s1.left(s1.length() - 1);

        array = tcpSocket->readLine();
        s2=QString(array);
        s2=s2.left(s2.length() - 1);
        id=s2.toInt();
        mainwindow->changeSections(s1.toStdString(),id);

    }
    else if(str=="-1\n")
    {
        break;
    }
    else if(str=="-2\n")
    {
        mainwindow->showPosts();
        break;
    }
    else if(str=="-3\n")
    {
        mainwindow->showComments();
        break;
    }
    else if(str=="-4\n")
    {
        break;
    }
    else if(str=="-5\n")
    {
        break;
    }
    else if(str=="-6\n")
    {
        break;
    }
    }

}

void ClientWidget::deletePost(int id)
{
    QString ID;
    ID=QString::number(id);
    ID+="\n";
    tcpSocket->write("7\n");
    tcpSocket->write(ID.toUtf8().data());
}

void ClientWidget::deleteComment(int id)
{
    QString ID;
    ID=QString::number(id);
    ID+="\n";
    tcpSocket->write("8\n");
    tcpSocket->write(ID.toUtf8().data());
}



void ClientWidget::connectServer()
{
    QString ipSer = "127.0.0.1";//ui->lineEditIP->text();
    qint16 portSer = 8888;//ui->lineEditPort->text().toInt();
    //主动和服务器建立连接
    tcpSocket->connectToHost(QHostAddress(ipSer),portSer);
}

void ClientWidget::sendIn(QString userName,QString password)
{
    //给对方发送数据
    userName+="\n";
    tcpSocket->write("1\n");
    if(mainwindow->getuserButton(0)->isChecked())
    {
        tcpSocket->write("0\n");
    }
    else if(mainwindow->getuserButton(1)->isChecked())
    {
        tcpSocket->write("2\n");
    }
    else
     {
        tcpSocket->write("1\n");
    }
    tcpSocket->write(userName.toUtf8().data());
    tcpSocket->write(password.toUtf8().data());
}

void ClientWidget::getPost(int sectionnum)
{
    tcpSocket->write("2\n");
    //QString str = QString::number(sectionnum);
    //tcpSocket->write(str.toUtf8().data());
}

void ClientWidget::getComments(int id)
{
    tcpSocket->write("3\n");
   // QString str = QString::number(id);
    //tcpSocket->write(str.toUtf8().data());
}

void ClientWidget::sendnewPost(string s1,string s2,string s3,string s4,int id,int sectionnum)
{
    QString ID,userName,title,content,time,section;

    userName = QString::fromStdString(s1);
    userName+="\n";
    title = QString::fromStdString(s2);
    title+="\n";
    content = QString::fromStdString(s3);
    content+="\n";
    time=QString::fromStdString(s4);
    time+="\n";
    ID=QString::number(id);
    ID+="\n";
    section=QString::number(sectionnum);
    section+="\n";

    tcpSocket->write("5\n");
    tcpSocket->write(ID.toUtf8().data());
    tcpSocket->write(userName.toUtf8().data());
    tcpSocket->write(title.toUtf8().data());
    tcpSocket->write(time.toUtf8().data());
    tcpSocket->write(section.toUtf8().data());
    tcpSocket->write(content.toUtf8().data());
    tcpSocket->write("\nend\n");
}

void ClientWidget::sendnewComment(string s1,string s2,string s3,int id,int postid)
{
    QString ID,userName,content,time,post;
    userName = QString::fromStdString(s1);
    userName+="\n";
    time=QString::fromStdString(s2);
    time+="\n";
    content = QString::fromStdString(s3);
    content+="\n";
    ID=QString::number(id);
    ID+="\n";
    post=QString::number(postid);
    post+="\n";

    tcpSocket->write("6\n");
    tcpSocket->write(ID.toUtf8().data());
    tcpSocket->write(userName.toUtf8().data());
    tcpSocket->write(time.toUtf8().data());
    tcpSocket->write(post.toUtf8().data());
    tcpSocket->write(content.toUtf8().data());
    tcpSocket->write("\nend\n");
}

int ClientWidget::getInResult()
{
    return Inresult;
}

void ClientWidget::sendOut(QString id,QString time)
{
    tcpSocket->write("4\n");
    QString kind;
    int userkind;
    userkind=mainwindow->getuserKind();
    kind=QString::number(userkind);
    kind+="\n";
    tcpSocket->write(kind.toUtf8().data());
    id+="\n";
    tcpSocket->write(id.toUtf8().data());
    time+="\n";
    tcpSocket->write(time.toUtf8().data());
}

void ClientWidget::changeModerator(string id1,string id2)
{
    tcpSocket->write("9\n");
    QString ID1,ID2;
    ID1=QString::fromStdString(id1);
    ID2=QString::fromStdString(id2);
    ID1+="\n";
    ID2+="\n";
    tcpSocket->write(ID1.toUtf8().data());
    tcpSocket->write(ID2.toUtf8().data());
}


void ClientWidget::registernewUser(QString userName,QString password)
{
    qDebug()<<"注册用户"<<endl;
    tcpSocket->write("10\n");
    userName+="\n";
    password+="\n";
    tcpSocket->write(userName.toUtf8().data());
    tcpSocket->write(password.toUtf8().data());

}

void ClientWidget::getSections()
{
    tcpSocket->write("11\n");
}
