#ifndef CLIENT_H
#define CLIENT_H
#include"post.h"
#include"comment.h"
#include"mainwindow.h"
#include"user.h"
#include<QString>
#include<QWidget>
#include<QTcpSocket>
#include<QHostAddress>

class ClientWidget: public QWidget
{
    Q_OBJECT
public:
    ClientWidget(MainWindow*parent);
    void connectServer();
    ~ClientWidget();
    void sendIn(QString userName,QString password);  //发送登录信息
    int getInResult();  //得到登录结果
    void getPost(int sectionnum);   //得到帖子
    void getComments(int id);  //得到评论
    void sendOut(QString id,QString time);  //注销操作
    void sendnewPost(string s1,string s2,string s3,string s4,int id,int sectionnum); //发送新帖子
    void sendnewComment(string s1,string s2,string s3,int id,int postid);  //发送评论
    void deletePost(int id);  //删除帖子
    void deleteComment(int id);     //删除评论
    void changeModerator(string id1,string id2);   //改变版主
    void registernewUser(QString userName,QString password);    //注册用户
    void getSections();  //得到板块信息

private slots:
    void readMessage();   //读取信息
private:
    //Ui::ClientWidget *ui;
    QTcpSocket * tcpSocket; //通信套接字对象
    int Inresult;    //判断用户登录结果
    MainWindow*mainwindow;

};

#endif // CLIENT_H
