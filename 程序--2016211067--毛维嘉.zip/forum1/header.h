#ifndef HEADER_H
#define HEADER_H

#include<iostream>
using namespace std;
//#include "user.h"
#include<vector>
#include "client.h"
#include "post.h"
#include "comment.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mainwindow.h"
#include <QApplication>
#include "user.h"
#include <string>
#include "string.h"
#include<QDebug>
#include"section.h"
#include <QTextStream>
#include<QFile>
#include<QPushButton>
#include<QLineEdit>
#include <QMainWindow>
#include<QPalette>
#include<QLabel>
#include <time.h>
#include <stdio.h>
#include<QIcon>
#include<QPixmap>
#include<QHBoxLayout>

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

#include <fstream>

#include <QTcpServer>   //监听套接字
#include <QTcpSocket>   //通信套接字

#include <QHostAddress>
#include <QByteArray>


#define mainwindowlength  1200
#define mainwindowheight  800
//#include <stdio.h>

#endif // HEADER_H



