
#include <QApplication>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include<test.h>
#include<qDebug>
#include <QWidget>
#include <QTcpServer>   //监听套接字
#include <QTcpSocket>   //通信套接字
#include<iostream>
#include"myserver.h"
using namespace std;

int main(int argc, char *argv[])
{
    QTextStream cin(stdin,  QIODevice::ReadOnly);
    QTextStream cout(stdout,  QIODevice::WriteOnly);
    QTextStream cerr(stderr,  QIODevice::WriteOnly);
    QApplication a(argc, argv);
    //Server server;
    //server.show();
    MyServer m;
    return a.exec();
}
