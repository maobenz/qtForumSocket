#ifndef MYSERVER_H
#define MYSERVER_H

#include <QTcpServer>

class MyThread;

class MyServer : public QTcpServer
{
    Q_OBJECT
public:
    MyServer(QWidget *parent = 0);
    virtual void incomingConnection(qintptr socketDescriptor);  //重写虚函数，这个函数用来接受从客户端传来的连接
};


#endif // MYSERVER_H
