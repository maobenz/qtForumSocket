#include "mysocket.h"

#include <QDataStream>
#include <QCryptographicHash>
#include <QSettings>
#include <QMessageBox>
#include <QDebug>


MySocket::MySocket(QWidget *parent, qintptr socket) : QTcpSocket(0)
{
    this->setSocketDescriptor(socket);
    qDebug()<<endl;

    connect(this, SIGNAL(readyRead()), this, SLOT(on_connected()));

    connect(this, &MySocket::disconnected, []{
        qDebug() << "disconnected";
    });



    if (QSqlDatabase::contains("qt_sql_default_connection"))  //连接数据库
    {
        database = QSqlDatabase::database("qt_sql_default_connection");
    }
    else
    {
        database = QSqlDatabase::addDatabase("QSQLITE");
        database.setDatabaseName("MyDataBase.db");
        database.setUserName("XingYeZhiXia");
        database.setPassword("123456");
    }

    if (!database.open())
    {
        qDebug() << "Error: Failed to connect database." << database.lastError();
    }
    else
    {

    }

    examineUserdatabase();
    examinePostdatabase();
    examineCommentdatabase();
    userkind=-1;
}

void MySocket::on_connected()
{
    qDebug() << "read client message";
    QByteArray buf;
    buf=this->readLine();
    QString str;
    int result;
    str = QString(buf);   //以下是读取从客户端发来的各种命令
    if(str=="1\n")
    {
        ifconform();
    }
    else if(str=="2\n")
    {
        sendPost();
    }
    else if(str=="3\n")
    {
        sendComments();
    }
    else if(str=="4\n")
    {

        QSqlQuery sql_query;
        QString update_sql;

        buf=this->readLine();
        QString kind;
        kind = QString(buf);

        buf=this->readLine();
        QString s1;
        s1 = QString(buf);
        s1=s1.left(s1.length()-1);

        buf=this->readLine();
        QString s2;
        s2 = QString(buf);
        s2=s2.left(s2.length()-1);

        if(kind=="0\n")
        {
            update_sql = "update administrator set lastonlinetime = :time where id = :id";
        }
        else if(kind=="1\n")
        {
            update_sql = "update ordinaryuser set lastonlinetime = :time where id = :id";
        }
        else if(kind=="2\n")
        {
            update_sql = "update moderator set lastonlinetime = :time where id = :id";
        }
        else if(kind=="3\n")
        {
            update_sql = "update anonymoususer set lastonlinetime = :time where id = :id";
        }

        sql_query.prepare(update_sql);
        sql_query.bindValue(":time", s2);
        sql_query.bindValue(":id", s1);
        if(!sql_query.exec())
        {
            qDebug() << sql_query.lastError();
        }
        else
        {
            qDebug() << "updated!";
        }
    }
    else if(str=="5\n")
    {
        receivenewPost();
    }
    else if(str=="6\n")
    {
        receivenewComment();
    }
    else if(str=="7\n")
    {
        deletePost();
    }
    else if(str=="8\n")
    {
        deleteComment();
    }
    else if(str=="9\n")
    {
        int i=changeModerator();
        if(i==0)
        {
            this->write("5\n");
            this->write("0\n");
            this->write("-5\n");
        }
        else if(i==1)
        {
            this->write("5\n");
            this->write("1\n");
            this->write("-5\n");
        }
    }
    else if(str=="10\n")
    {
        qDebug()<<"注册用户"<<endl;
        registerNewUser();
    }
    else if(str=="11\n")
    {
        sendSection();
    }
}

void MySocket::sendSection()  //发送板块号
{

    QString select_all_sql = "select * from moderator";
    QSqlQuery sql_query; sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            this->write("6\n");
            int id;
            QString s1,s2;
            s1 = sql_query.value(1).toString();   //名字
            id = sql_query.value(6).toInt();     //板块号
            s2=QString::number(id);
            s1+="\n";
            s2+="\n";
            this->write(s1.toUtf8().data());
            this->write(s2.toUtf8().data());
        }
    }
    this->write("-6\n");
}

void MySocket::registerNewUser()
{
    int result;
    QByteArray buf;
    buf=this->readLine();
    QString userName,password;
    userName = QString(buf);
    userName=userName.left(userName.length()-1);

    buf=this->readLine();
    password = QString(buf);
    password=password.left(password.length()-1);

    result=insertNewUser(userName,password);
    QString s;
    s=QString::number(result);
    s+="\n";
    this->write("4\n");
    this->write(s.toUtf8().data());
    this->write("-4\n");

}

int MySocket::insertNewUser(QString userName,QString password)
{
    qDebug()<<"注册用户"<<endl;
    QSqlQuery sql_query;
    QString select_all_sql;
    QString str;
    QString s1,s2;
    select_all_sql = "select * from ordinaryuser";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            s1=sql_query.value(0).toString();
            s2 = sql_query.value(1).toString();   //用户名
            if(s2==userName)
                return 1;
        }
    }

    QString insert_sql = "insert into ordinaryuser values (?, ?, ?,?,?,?)";
    sql_query.prepare(insert_sql);
    s1+=1;
    sql_query.addBindValue(s1);

    sql_query.addBindValue(userName);
    sql_query.addBindValue(password);
    str="";
    sql_query.addBindValue(str);
    sql_query.addBindValue(1);
    sql_query.addBindValue(0);
    if(!sql_query.exec())
    {
        qDebug() << sql_query.lastError();
    }
    else
    {
        qDebug() << "inserted ok!";
    }
    examineUserdatabase();
    return 0;
}

void MySocket::sendIninfor(int result)
{
    QString str;
    str=QString::number(result);
    if(this != NULL){
            this->write("1\n");   //发送登录结果
            str+="\n";
            QString qs = QString::number(userkind);
            qs+="\n";
            this->write(qs.toUtf8().data());
            this->write(str.toUtf8().data());
            this->write("-1\n");
        }
}



void MySocket::ifconform()
{
    QByteArray buf;
    QString userName,password,kind;
    QSqlQuery sql_query;
    QString insert_sql,select_all_sql;
    QString s1,s2,s3,s4,s5,s6,s7;
    QString str,qs;
    bool In=false;
    QString moderator[3],sID[3];
    int id[3],i=0;

    buf=this->readLine();
    kind = QString(buf);
    buf=this->readLine();
    userName = QString(buf);
    buf=this->readLine();
    password = QString(buf);
    userName = userName.left(userName.length() - 1);


    if(kind=="0\n")
    {
        select_all_sql = "select * from administrator";
        sql_query.prepare(select_all_sql);
        if(!sql_query.exec())
        {
            qDebug()<<sql_query.lastError();
        }
        else
        {
            while(sql_query.next())
            {
                s2 = sql_query.value(1).toString();   //用户名
                s3 = sql_query.value(2).toString();   //密码
                if(s2==userName)
                {
                    if(s3==password)
                    {
                        this->write("1\n");   //表明发送类型
                        str="0\n";
                        qs="0\n";
                        this->write(qs.toUtf8().data());//发送的用户类型
                        this->write(str.toUtf8().data()); //发送的结果类型
                        s2+="\n";
                        s3+="\n";
                        s1=sql_query.value(0).toString();    //ID
                        s1+="\n";
                        this->write(s1.toUtf8().data());
                        this->write(s2.toUtf8().data());  //用户名
                        this->write(s3.toUtf8().data());   //密码
                        s4=sql_query.value(3).toString();    //最后一次上线时间
                        s4+="\n";
                        this->write(s4.toUtf8().data());

                        this->write("-1\n");//发送结束标志
                        In=true;
                    }
                    else if (s3!=password)
                    {
                        this->write("1\n");   //表明发送类型
                        this->write("0\n");
                        str="2\n";
                        this->write(str.toUtf8().data()); //发送的结果类型
                         this->write("-1\n");
                        In=true;
                    }
                }
            }
            if(In==false)
            {
                this->write("1\n");   //表明发送类型
                this->write("0\n");
                str="1\n";

                this->write(str.toUtf8().data()); //发送的结果类型
                 this->write("-1\n");
            }
        }
    }
    else if(kind=="1\n")
    {
        In=false;
        select_all_sql = "select * from ordinaryuser";
        sql_query.prepare(select_all_sql);
        if(!sql_query.exec())
        {
            qDebug()<<sql_query.lastError();
        }
        else
        {
            while(sql_query.next())
            {
                s2 = sql_query.value(1).toString();   //用户名
                s3 = sql_query.value(2).toString();   //密码
                if(s2==userName)
                {
                    if(s3==password)
                    {
                        this->write("1\n");   //表明发送类型
                        str="0\n";
                        qs="1\n";
                        this->write(qs.toUtf8().data());//发送的用户类型
                        this->write(str.toUtf8().data()); //发送的结果类型
                        s2+="\n";
                        s3+="\n";
                        s1=sql_query.value(0).toString();    //ID
                        s1+="\n";
                        this->write(s1.toUtf8().data());
                        this->write(s2.toUtf8().data());  //用户名
                        this->write(s3.toUtf8().data());   //密码
                        s4=sql_query.value(3).toString();    //最后一次上线时间
                        s4+="\n";
                        this->write(s4.toUtf8().data());

                        s5=sql_query.value(4).toString();    //等级
                        s5+="\n";
                        this->write(s5.toUtf8().data());

                        s6=sql_query.value(5).toString();    //被举报次数
                        s6+="\n";
                        this->write(s6.toUtf8().data());

                        this->write("-1\n");//发送结束标志
                        In=true;

                    }
                    else if (s3!=password)
                    {
                        this->write("1\n");   //表明发送类型
                        this->write("1\n");
                        str="2\n";

                        this->write(str.toUtf8().data()); //发送的结果类型
                        In=true;
                         this->write("-1\n");
                    }
                }
            }
        }

        select_all_sql = "select * from moderator";
        sql_query.prepare(select_all_sql);
        if(!sql_query.exec())
        {
            qDebug()<<sql_query.lastError();
        }
        else
        {
            while(sql_query.next())
            {
                s2 = sql_query.value(1).toString();   //用户名
                s3 = sql_query.value(2).toString();   //密码
                if(s2==userName)
                {
                    if(s3==password)
                    {
                        this->write("1\n");   //表明发送类型
                        str="0\n";
                        qs="2\n";
                        this->write(qs.toUtf8().data());//发送的用户类型
                        this->write(str.toUtf8().data()); //发送的结果类型
                        s2+="\n";
                        s3+="\n";
                        s1=sql_query.value(0).toString();    //ID
                        s1+="\n";
                        this->write(s1.toUtf8().data());
                        this->write(s2.toUtf8().data());  //用户名
                        this->write(s3.toUtf8().data());   //密码
                        s4=sql_query.value(3).toString();    //最后一次上线时间
                        s4+="\n";
                        this->write(s4.toUtf8().data());

                        s5=sql_query.value(4).toString();    //等级
                        s5+="\n";
                        this->write(s5.toUtf8().data());

                        s6=sql_query.value(5).toString();    //被举报次数
                        s6+="\n";
                        this->write(s6.toUtf8().data());

                        s7=sql_query.value(6).toString();    //板块号
                        s7+="\n";
                        this->write(s7.toUtf8().data());

                        this->write("-1\n");//发送结束标志
                        In=true;
                    }
                    else if (s3!=password)
                    {
                        this->write("1\n");   //表明发送类型
                        this->write("2\n");
                        str="2\n";
                        this->write(str.toUtf8().data()); //发送的结果类型
                        In=true;
                         this->write("-1\n");
                    }
                }
            }
            if(In==false)
            {
                this->write("1\n");   //表明发送类型
                this->write("2\n");
                str="1\n";
                this->write(str.toUtf8().data()); //发送的结果类型
                 this->write("-1\n");
            }
        }
    }
    else if(kind=="2\n")
    {
        select_all_sql = "select * from anonymoususer";
        sql_query.prepare(select_all_sql);
        if(!sql_query.exec())
        {
            qDebug()<<sql_query.lastError();
        }
        else
        {
            while(sql_query.next())
            {
                s2 = sql_query.value(1).toString();   //用户名
                s3 = sql_query.value(2).toString();   //密码
                if(s2==userName)
                {
                    if(s3==password)
                    {
                        this->write("1\n");   //表明发送类型
                        str="0\n";
                        qs="3\n";
                        this->write(qs.toUtf8().data());//发送的用户类型
                        this->write(str.toUtf8().data()); //发送的结果类型
                        s2+="\n";
                        s3+="\n";
                        s1=sql_query.value(0).toString();    //ID
                        s1+="\n";
                        this->write(s1.toUtf8().data());
                        this->write(s2.toUtf8().data());  //用户名
                        this->write(s3.toUtf8().data());   //密码
                        s4=sql_query.value(3).toString();    //最后一次上线时间
                        s4+="\n";
                        this->write(s4.toUtf8().data());

                        this->write("-1\n");//发送结束标志
                        In=true;
                    }
                    else if (s3!=password)
                    {
                        this->write("1\n");   //表明发送类型
                        this->write("3\n");
                        str="2\n";
                        this->write(str.toUtf8().data()); //发送的结果类型
                        In=true;
                         this->write("-1\n");
                    }
                }
            }
            if(In==false)
            {
                this->write("1\n");   //表明发送类型
                this->write("3\n");
                str="1\n";
                this->write(str.toUtf8().data()); //发送的结果类型
                 this->write("-1\n");
            }
        }
    }

}


void MySocket::receivenewComment()
{
    QByteArray buf,array;
    QString id,userName,content,time,str,post;
    int postid;

    buf=this->readLine();
    id = QString(buf);
    id=id.left(id.length()-1);

    buf=this->readLine();
    userName = QString(buf);
    userName= userName.left( userName.length()-1);


    buf=this->readLine();
    time = QString(buf);
    time=time.left(time.length()-1);

    buf=this->readLine();
    post = QString(buf);
    post=post.left(post.length()-1);
    postid=post.toInt();

    content="";
    while(1)
    {
        array= this->readLine();
        str=QString(array);
        if(str=="end\n")
            break;
        else
            content+=str;
    }
    content=content.left(content.length()-1);



    QSqlQuery sql_query;
    QString insert_sql = "insert into Comment values (?,?,?,?,?)";
    sql_query.prepare(insert_sql);
    sql_query.addBindValue(id);
    sql_query.addBindValue(userName);
    sql_query.addBindValue(time);
    sql_query.addBindValue(content);
    sql_query.addBindValue(postid);
    if(!sql_query.exec())
    {
        qDebug() << sql_query.lastError();
    }
    else
    {
        qDebug() << "inserted ok!";
    }

    examineCommentdatabase();
}


void MySocket::receivenewPost()
{
    QByteArray buf,array;
    QString id,userName,title,content,time,str,section;
    int sectionnum;

    buf=this->readLine();
    id = QString(buf);
    id=id.left(id.length()-1);

    buf=this->readLine();
    userName = QString(buf);
    userName= userName.left( userName.length()-1);

    buf=this->readLine();
    title = QString(buf);
    title=title.left(title.length()-1);

    buf=this->readLine();
    time = QString(buf);
    time=time.left(time.length()-1);

    buf=this->readLine();
    section = QString(buf);
    section=section.left(section.length()-1);
    sectionnum=section.toInt();


    content="";
    while(1)
    {
        array= this->readLine();
        str=QString(array);
        if(str=="end\n")
            break;
        else
            content+=str;
    }
    content=content.left(content.length()-1);


    QSqlQuery sql_query;
    QString insert_sql = "insert into Post values (?,?,?,?,?,?)";
    sql_query.prepare(insert_sql);
    sql_query.addBindValue(id);
    sql_query.addBindValue(userName);
    sql_query.addBindValue(time);
    sql_query.addBindValue(title);
    sql_query.addBindValue(content);
    sql_query.addBindValue(sectionnum);
    if(!sql_query.exec())
    {
        qDebug() << sql_query.lastError();
    }
    else
    {
        qDebug() << "inserted ok!";
    }
    examinePostdatabase();
}



int MySocket::getCondition()
{
    return kind;
}

void MySocket::sendComments()
{

    QByteArray buf;
    QString str;

    //str = QString(buf);
    //str+="\n";
    //int post = str.toInt();

    QString select_all_sql;
    QSqlQuery sql_query;

    select_all_sql = "select * from Comment";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            int  id= sql_query.value(0).toInt();
            QString username = sql_query.value(1).toString();
            QString time = sql_query.value(2).toString();   //时间
            QString content = sql_query.value(3).toString();  //内容
            int postid = sql_query.value(4).toInt();

            //if(post==postid)
            //{
                if(this != NULL){
                        this->write("3\n");
                        QString ID = QString::number(id);
                        ID+="\n";
                        this->write(ID.toUtf8().data());
                        username+="\n";
                        this->write(username.toUtf8().data());
                        time+="\n";
                        this->write(time.toUtf8().data());


                        str= QString::number(postid);
                        str+="\n";
                        this->write(str.toUtf8().data());

                        this->write(content.toUtf8().data());

                        this->write("\nend\n");
                    }
                //qDebug()<<QString("id:%1    username:%2    time:%3    title:%4     content:%5    sectionnum:%6" ).arg(id)
                          //.arg(username).arg(time).arg(title).arg(content).arg(sectionnum);
            //}
        }

        this->write("-3\n");
    }
}



void MySocket::sendPost()
{
    QByteArray buf;
    buf=this->readLine();
    QString str;

    QString select_all_sql;
    QSqlQuery sql_query;

    select_all_sql = "select * from Post";  //发送帖子
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            int  id= sql_query.value(0).toInt();
            QString username = sql_query.value(1).toString();
            QString time = sql_query.value(2).toString();
            QString title = sql_query.value(3).toString();
            QString content = sql_query.value(4).toString();
            int sectionnum = sql_query.value(5).toInt();
           // if(section==sectionnum)
            //{
                if(this != NULL){
                        this->write("2\n");
                        QString ID = QString::number(id);
                        ID+="\n";
                        this->write(ID.toUtf8().data());
                        username+="\n";
                        this->write(username.toUtf8().data());
                        time+="\n";
                        this->write(time.toUtf8().data());
                        title+="\n";

                        QString section;
                        section=QString::number(sectionnum);
                        section+="\n";

                        this->write(title.toUtf8().data());
                        this->write(section.toUtf8().data());
                        this->write(content.toUtf8().data());
                        this->write("\nend\n");

                    }
                qDebug()<<QString("id:%1    username:%2    time:%3    title:%4     content:%5    sectionnum:%6" ).arg(id)
                          .arg(username).arg(time).arg(title).arg(content).arg(sectionnum);
            //}
        }
        this->write("-2\n");
    }
}

void MySocket::examinePostdatabase()
{
    QString str;
    QString select_all_sql;
    QSqlQuery sql_query;

    select_all_sql = "select * from Post";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            int  id= sql_query.value(0).toInt();
            QString username = sql_query.value(1).toString();
            QString time = sql_query.value(2).toString();
            QString title = sql_query.value(3).toString();
            QString content = sql_query.value(4).toString();
            int sectionnum= sql_query.value(5).toInt();
            qDebug()<<QString("id:%1    username:%2    time:%3    title:%4     content:%5    sectionnum:%6" ).arg(id)
                      .arg(username).arg(time).arg(title).arg(content).arg(sectionnum);
        }
    }
}


void MySocket::examineCommentdatabase()
{
    QString str;
    QString select_all_sql;
    QSqlQuery sql_query;

    select_all_sql = "select * from Comment";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            int  id= sql_query.value(0).toInt();
            QString username = sql_query.value(1).toString();
            QString time = sql_query.value(2).toString();
            QString content = sql_query.value(3).toString();
            int postid=sql_query.value(4).toInt();
            qDebug()<<QString("id:%1    username:%2    time:%3     content:%4  postid:%5" ).arg(id)
                      .arg(username).arg(time).arg(content).arg(postid);
        }
    }
}


void MySocket::examineUserdatabase()
{


    QSqlQuery sql_query;
    QString insert_sql;
    int i;
    QString str;
    QString select_all_sql;


    select_all_sql = "select * from administrator";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            QString  id= sql_query.value(0).toString();
            QString name = sql_query.value(1).toString();
            QString password = sql_query.value(2).toString();
            QString lasttime = sql_query.value(3).toString();
            qDebug()<<QString("id:%1    name:%2    password:%3     lasttime:%4" ).arg(id)
                      .arg(name).arg(password).arg(lasttime);
        }
    }







    select_all_sql = "select * from ordinaryuser";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {

            QString id = sql_query.value(0).toString();
            QString name = sql_query.value(1).toString();
            QString password = sql_query.value(2).toString();
            QString lastonlineTime = sql_query.value(3).toString();
            int level = sql_query.value(4).toInt();
            int accusationtimes = sql_query.value(5).toInt();
            qDebug()<<QString("id:%1    name:%2    password:%3   "
                              " lastonlineTime:%4   level:%5   accusationtimes:%6  "
                              ).arg(id)
                      .arg(name).arg(password).arg(lastonlineTime).arg(level).
                      arg(accusationtimes);
        }
    }


    select_all_sql = "select * from moderator";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {

            QString id = sql_query.value(0).toString();
            QString name = sql_query.value(1).toString();
            QString password = sql_query.value(2).toString();
            QString lastonlineTime = sql_query.value(3).toString();
            int level = sql_query.value(4).toInt();
            int accusationtimes = sql_query.value(5).toInt();
            int section=sql_query.value(6).toInt();
            qDebug()<<QString("id:%1    name:%2    password:%3   "
                              " lastonlineTime:%4   level:%5   accusationtimes:%6  "
                              "section:%7"
                              ).arg(id)
                      .arg(name).arg(password).arg(lastonlineTime).arg(level).
                      arg(accusationtimes).arg(section);
        }
    }



    select_all_sql = "select * from anonymoususer";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {


            QString  id= sql_query.value(0).toString();
            //QString Title = sql_query.value(3).toString();
            QString name = sql_query.value(1).toString();
            QString password = sql_query.value(2).toString();
            QString lasttime = sql_query.value(3).toString();


            qDebug()<<QString("id:%1    name:%2    password:%3     lasttime:%4" ).arg(id)
                      .arg(name).arg(password).arg(lasttime);
        }
    }



}


void MySocket::deletePost()
{
    QByteArray buf;
    QString id;
    int ID;
    buf=this->readLine();
    id = QString(buf);
    id=id.left(id.length()-1);
    ID=id.toInt();
    deletepostdatabase(ID);

}

void MySocket::deletepostdatabase(int id)
{
    QSqlQuery sql_query;
    QString delete_sql = "delete from Post where id = ?";  //删除帖子
    sql_query.prepare(delete_sql);
    sql_query.addBindValue(id);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        qDebug()<<"deleted!";
    }


    delete_sql = "delete from Comment where postid = ?";
    sql_query.prepare(delete_sql);
    sql_query.addBindValue(id);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        qDebug()<<"deleted!";
    }

    examinePostdatabase();
    examineCommentdatabase();


}


void MySocket::deleteComment()
{
    QByteArray buf;
    QString id;
    int ID;
    buf=this->readLine();
    id = QString(buf);
    id=id.left(id.length()-1);
    ID=id.toInt();
    deletecommentdatabase(ID);

}

void MySocket::deletecommentdatabase(int id)
{
    QSqlQuery sql_query;
    QString delete_sql = "delete from Comment where id = ?";
    sql_query.prepare(delete_sql);
    sql_query.addBindValue(id);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        qDebug()<<"deleted!";
    }
    examineCommentdatabase();
}

int MySocket::changeModerator()   //更换版主
{
    QByteArray buf;
    QString id1,id2;
    QString userName1,userName2;
    buf=this->readLine();
    userName1 = QString(buf);
    userName1=userName1.left(userName1.length()-1);

    buf=this->readLine();
    userName2 = QString(buf);
    userName2=userName2.left(userName2.length()-1);


    int i;
    QString s1,s2,s3,s4;
    QString S1,S2,S3,S4;
    bool In;
    In=false;

    int n1,n2,n3;
    int N1,N2,N3;

    QSqlQuery sql_query;
    QString insert_sql;
    QString str;

    QString select_all_sql = "select * from ordinaryuser";
    sql_query.prepare(select_all_sql);

    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {
            s2 = sql_query.value(1).toString();
            if(userName1==s2)
            {
                In=true;
                s1 = sql_query.value(0).toString();
                id2=s1;

                s3 = sql_query.value(2).toString();
                s4 = sql_query.value(3).toString();
                n1 = sql_query.value(4).toInt();
                n2 = sql_query.value(5).toInt();
                break;
            }
        }
    }
    if(In==false)
    {
        return 1;
    }


    select_all_sql = "select * from moderator";
    sql_query.prepare(select_all_sql);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        while(sql_query.next())
        {

            S2 = sql_query.value(1).toString();
            if(userName2==S2)
            {
                S1 = sql_query.value(0).toString();
                id1=S1;
                S3 = sql_query.value(2).toString();
                S4 = sql_query.value(3).toString();
                N1 = sql_query.value(4).toInt();
                N2 = sql_query.value(5).toInt();
                N3 = sql_query.value(6).toInt();
                break;
            }
        }
    }
    //qDebug()<<N3<<"mm"<<S2<<endl;

    insertmoderatorDatabase(s1.toStdString(),s2.toStdString(),s3.toStdString(),s4.toStdString(),n1,n2,N3);
    insertordinaryuserDatabase(S1.toStdString(),S2.toStdString(),S3.toStdString(),
                               S4.toStdString(),N1,N2);
    //examineUserdatabase();

    deleteordinaryuserDatabase(id2.toStdString());
    deletemoderatorDatabase(id1.toStdString());
    //examineUserdatabase();
    return 0;

}

void MySocket::deleteordinaryuserDatabase(string id)   //删除普通用户
{
    QSqlQuery sql_query;
    QString delete_sql = "delete from ordinaryuser where id = ?";
    QString str;
    str=QString::fromStdString(id);
    sql_query.prepare(delete_sql);
    sql_query.addBindValue(str);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        qDebug()<<"deleted!";
    }
}

void MySocket::deletemoderatorDatabase(string id)  //删除版主
{
    QSqlQuery sql_query;
    QString delete_sql = "delete from moderator where id = ?";
    QString str;
    str=QString::fromStdString(id);
    sql_query.prepare(delete_sql);
    sql_query.addBindValue(str);
    if(!sql_query.exec())
    {
        qDebug()<<sql_query.lastError();
    }
    else
    {
        qDebug()<<"deleted!";
    }
}

void MySocket::insertmoderatorDatabase(string id,string name,string password,string time,int level,
                             int accusationtimes,int section)
{

    QSqlQuery sql_query;
    QString str;
    QString insert_sql = "insert into moderator values (?, ?, ?,?,?,?,?)";
    sql_query.prepare(insert_sql);
    str=QString::fromStdString(id);
    qDebug()<<str<<"tytyt"<<endl;
    sql_query.addBindValue(str);
    str=QString::fromStdString(name);
    sql_query.addBindValue(str);
    str=QString::fromStdString(password);
    sql_query.addBindValue(str);
    str=QString::fromStdString(time);
    sql_query.addBindValue(str);
    sql_query.addBindValue(level);
    sql_query.addBindValue(accusationtimes);
    sql_query.addBindValue(section);
    if(!sql_query.exec())
    {
        qDebug() << sql_query.lastError();
    }
    else
    {
        qDebug() << "inserted ok!";
    }
}


void MySocket::insertordinaryuserDatabase(string id,string name,string password,string time,int level,int accusationtimes)
{
    QSqlQuery sql_query;
    QString str;
    QString insert_sql = "insert into ordinaryuser values (?, ?, ?,?,?,?)";
    sql_query.prepare(insert_sql);
    str=QString::fromStdString(id);
    sql_query.addBindValue(str);
    str=QString::fromStdString(name);
    sql_query.addBindValue(str);
    str=QString::fromStdString(password);
    sql_query.addBindValue(str);
    str=QString::fromStdString(time);
    sql_query.addBindValue(str);
    sql_query.addBindValue(level);
    sql_query.addBindValue(accusationtimes);
    if(!sql_query.exec())
    {
        qDebug() << sql_query.lastError();
    }
    else
    {
        qDebug() << "inserted ok!";
    }
}
