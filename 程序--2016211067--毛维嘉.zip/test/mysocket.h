#ifndef MYSOCKET_H
#define MYSOCKET_H

#include <QTcpSocket>
#include <QFile>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include<iostream>
using namespace std;
#include<string>
#include<QString>


class MySocket : public QTcpSocket
{
    Q_OBJECT
public:
    MySocket(QWidget *parent, qintptr socket);
    //处理新来的链接
    int getCondition();
    void ifconform();  //判断输入密码账号是否正确
    void sendIninfor(int result);
    void sendPost();  //发送帖子
    void examinePostdatabase();   //检查帖子数据库
    void examineCommentdatabase();   //检查评论数据库
    void examineUserdatabase();   //检查用户数据库
    void examineSectiondatabase();   //检查板块数据库
    void sendComments();    //发送评论
    void receivenewPost();   //收到新帖子
    void receivenewComment();   //收到新评论
    void deletePost();   //删除帖子
    void deletepostdatabase(int id);   //删除评论数据库中某个记录
    void deleteComment();  //删除评论
    void deletecommentdatabase(int id);   //删除评论数据库中某个记录
    int changeModerator();
    void deleteordinaryuserDatabase(string id);
    void deletemoderatorDatabase(string id);
    void insertmoderatorDatabase(string id,string name,string password,string time,int level,
                                 int accusationtimes,int section);
    void insertordinaryuserDatabase(string id,string name,string password,
                                                string time,int level,int accusationtimes);
    void registerNewUser();
    int insertNewUser(QString userName,QString password);
    void sendSection();   //发送板块信息


public slots:
    void on_connected();

private:
    QSqlDatabase database;   //定义数据库
    int userkind;   //定义用户种类
    int kind;   //定义接受的种类

};

#endif // MYSOCKET_H
