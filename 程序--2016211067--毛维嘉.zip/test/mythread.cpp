#include "mythread.h"
#include "mysocket.h"
#include <QDebug>


MyThread::MyThread(QWidget *parent, qintptr socket) : QThread(parent)
{
    this->p = socket;
    connect(this, SIGNAL(finished()), SLOT(deletLater()));
}

void MyThread::run()
{
    MySocket *socket = new MySocket(0, this->p);
    connect(socket, &MySocket::disconnected, this, &MyThread::quit, Qt::DirectConnection);
    this->exec();
}
