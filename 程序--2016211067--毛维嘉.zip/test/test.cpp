#include "test.h"

test::test()
{
    a=1;
}


int test::getA()
{
    return a;
}

test test::operator << (const test&b)
{
    test t;
    t.a=this->a+b.a;
    return t;
}
