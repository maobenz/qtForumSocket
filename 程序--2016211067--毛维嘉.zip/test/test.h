#ifndef TEST_H
#define TEST_H


class test
{
public:
    test();
    test operator<<(const test& b);
    int getA();
    int a;
};

#endif // TEST_H
